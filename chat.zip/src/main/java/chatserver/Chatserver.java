package chatserver;

import java.io.*;
import java.net.*;
import java.util.HashMap;

import util.Config;
import util.Log;
import util.User;

public class Chatserver implements IChatserverCli, Runnable {

	private String componentName;
	private Config config;
	private InputStream userRequestStream;
	private PrintStream userResponseStream;

	protected Thread runningThread = null;
	protected boolean isStopped = false;
	private ServerSocket serverSocket;
	private HashMap<Socket, User> users;

	/**
	 * @param componentName
	 *            the name of the component - represented in the prompt
	 * @param config
	 *            the configuration to use
	 * @param userRequestStream
	 *            the input stream to read user input from
	 * @param userResponseStream
	 *            the output stream to write the console output to
	 */
	public Chatserver(String componentName, Config config,
			InputStream userRequestStream, PrintStream userResponseStream) {
		this.componentName = componentName;
		this.config = config;
		this.userRequestStream = userRequestStream;
		this.userResponseStream = userResponseStream;
		this.users = new HashMap<>();
	}

	@Override
	public void run() {
		// create and start a new TCP ServerSocket
		DatagramSocket sock;
		try {
			sock = new DatagramSocket(config.getInt("udp.port"));
		} catch (SocketException e) {
			throw new RuntimeException("Cannot listen on UDP port.", e);
		}
		try {
			synchronized(this) {
				this.runningThread = Thread.currentThread();
			}
			// handle incoming connections from client in a separate thread
			serverSocket = new ServerSocket(config.getInt("tcp.port"));
		} catch (IOException e) {
			throw new RuntimeException("Cannot listen on TCP port.", e);
		}
		System.out.println("Server is up! Hit <ENTER> to exit!");
		DatagramSocket udpSocket = null;
		try {
			udpSocket = new DatagramSocket(9876);
		} catch (SocketException e) {
			e.printStackTrace();
		}
		byte[] receiveData = new byte[1024];
		byte[] sendData = new byte[1024];
		while (!isStopped()) {
			DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
			try {
				System.out.println("..waiting for udp");
				udpSocket.receive(receivePacket);
			} catch (IOException | NullPointerException e) {
				e.printStackTrace();
			}
			String sentence = new String( receivePacket.getData());
			System.out.println("RECEIVED: " + sentence);
//			Socket socket = null;
//			try {
//				socket = serverSocket.accept();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//			new Log("Spawning new TCP-Thread");
//			new Thread(
//				new TcpThread(socket, users)
//			).start();
		}
//		// create a reader to read from the console
//		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
//		try {
//			// read commands from the console
//			reader.readLine();
//		} catch (IOException e) {
//			// IOException from System.in is very very unlikely (or impossible)
//			// and cannot be handled
//		}

		// close socket and listening thread
		try {
			exit();
		} catch(IOException e) {
			new Log("Cannot close server.");
			throw new RuntimeException("Cannot close server.", e);
		}
	}

	@Override
	public String users() throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String exit() throws IOException {
		if (serverSocket != null) {
			isStopped = true;
			try {
				serverSocket.close();
			} catch (IOException e) {
				// Ignored because we cannot handle it
			}
		}
		return null;
	}

	/**
	 * @param args
	 *            the first argument is the name of the {@link Chatserver}
	 *            component
	 */
	public static void main(String[] args) {
		Chatserver chatserver = new Chatserver(args[0],
				new Config("chatserver"), System.in, System.out);
		// TODO: start the chatserver
		chatserver.run();
	}

	protected synchronized boolean isStopped() {
		return isStopped;
	}

}
